import pandas as pd
import csv
import argparse

df = pd.read_csv('Datasets/2022/Mushroom.csv')

headers = []
for col in df.columns[1:]:
    for item in df[col].unique():
        if df[col].value_counts()[item]/df[col].count() <= .1:
            header = col + '-' + item
            df[header] = df[col] == item

df['C'] = df['Class'] == 'e'
df *= 1
df['C'].replace({0:2},inplace=True)
df.drop(df.columns[range(23)], axis = 1, inplace = True)
#df = df[df['stalk-root-?'] == 0]
df.to_csv('Mushroom_processed_0.1_dropped.csv', index=False)
