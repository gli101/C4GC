import pandas as pd
import csv
import argparse
import math

df = pd.read_csv('Datasets/2022/adult.csv')
df.drop('education.num', axis=1, inplace=True)

numeric = {'age':[17,25,40,60,90], 'fnlwgt': None, 'capital.gain':None, 'capital.loss':None, 'hours.per.week':[0,25,50,75,100]}
skip = {'fnlwgt','capital.gain','capital.loss'}

for col in df.columns[:-1]:
    if col not in numeric:
        for item in df[col].unique():
            header = col + '_' + item
            df[header] = df[col] == item
    elif col not in skip:
        mn = df[col].min()
        mx = df[col].max()
        bins = []
        for i in range(5):
            bins.append([])
        for idx,itm in enumerate(df[col]):
            for i in range(1,6):
                if itm <= mn + i*(mx-mn)/5:
                    bins[i-1].append(1)
                    for j in range(i+1,6):
                        bins[j-1].append(0)
                    break
                else:
                    bins[i-1].append(0)
        for i in range(1,6):
            flr = math.floor(mn + (i-1)*(mx-mn)/5)
            cel = math.ceil(mn + i*(mx-mn)/5)
            header = col + '_' + str(flr) + '-' + str(cel)
            df[header] = bins[i-1]
    else:
        continue
        

df['C'] = df['income'] == '<=50K'
df *= 1
df['C'].replace({0:2},inplace=True)
df.drop(df.columns[range(14)], axis = 1, inplace = True)

df = df[df['workclass_?'] == 0]
df = df[df['occupation_?'] == 0]
df = df[df['native.country_?'] == 0]

df.drop('workclass_?', axis=1, inplace=True)
df.drop('occupation_?', axis=1, inplace=True)
df.drop('native.country_?', axis=1, inplace=True)

df.to_csv('adult_processed.csv', index=False)